
/*
  ai_engine.js - Hybrid Local Learner (Memory + Naive Bayes)
  - Runs fully locally in browser/WebView, no remote calls, no code self-modification.
  - Stores memory and model in localStorage under keys: ai_memory_v2, ai_nb_model_v1
  - Memory: list of {input, response, count}
  - Model: simple multinomial Naive Bayes (token counts per response label)
  - APIs:
      send(input) -> {response, source, probs}
      train(pairs) -> train model from pairs [{input, response}]
      reinforce(input, response) -> increment memory & retrain
      exportMemory(), importMemory(json, merge)
      exportModel(), importModel(json, merge)
      clearMemory(), clearModel()
  - Safety: DOES NOT modify JS files or execute arbitrary code. All learning updates model parameters only.
*/

(function(window){
  const MEM_KEY = 'ai_memory_v2';
  const MODEL_KEY = 'ai_nb_model_v1';
  const DEFAULT_RESPONSES = [
    "Maaf, aku belum tahu jawaban itu.",
    "Bisa jelaskan lebih detail?",
    "Aku akan mencatat itu dan belajar."
  ];

  // --- util ---
  function loadJSON(key){ try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; } catch(e){ console.warn('ai loadJSON', e); return null; } }
  function saveJSON(key, val){ try { localStorage.setItem(key, JSON.stringify(val)); } catch(e){ console.warn('ai saveJSON', e); } }

  function tokenize(s){
    if(!s) return [];
    return s.toLowerCase().split(/[^a-z0-9\u00C0-\u024F]+/).filter(Boolean);
  }

  // --- memory management ---
  function loadMemory(){ const m = loadJSON(MEM_KEY); return Array.isArray(m) ? m : []; }
  function saveMemory(mem){ saveJSON(MEM_KEY, mem); }

  // --- naive bayes model ---
  // model structure:
  // { labels: {label: {count: n, tokenCounts: {token: count}}}, docCount: N, vocab: {token:count} }
  function emptyModel(){ return { labels: {}, docCount: 0, vocab: {} }; }
  function loadModel(){ const m = loadJSON(MODEL_KEY); return m && typeof m === 'object' ? m : emptyModel(); }
  function saveModel(model){ saveJSON(MODEL_KEY, model); }

  function trainFromMemory(){
    const mem = loadMemory();
    const model = emptyModel();
    for(const item of mem){
      const label = item.response || '__UNKNOWN__';
      const tokens = tokenize(item.input||'');
      if(!model.labels[label]) model.labels[label] = { count: 0, tokenCounts: {} };
      model.labels[label].count += (item.count||1);
      model.docCount += (item.count||1);
      for(const t of tokens){
        model.vocab[t] = (model.vocab[t]||0) + (item.count||1);
        model.labels[label].tokenCounts[t] = (model.labels[label].tokenCounts[t]||0) + (item.count||1);
      }
    }
    saveModel(model);
    return model;
  }

  function train(pairs){
    // pairs: [{input, response}]
    if(!Array.isArray(pairs)) return false;
    const mem = loadMemory();
    for(const p of pairs){
      if(!p || !p.input || !p.response) continue;
      // check existing same input/response
      const exists = mem.find(m => m.input === p.input && m.response === p.response);
      if(exists) exists.count = (exists.count||0) + 1;
      else mem.push({ input: p.input, response: p.response, count: 1 });
    }
    saveMemory(mem);
    const model = trainFromMemory();
    return model;
  }

  // naive bayes prediction (multinomial)
  function predictNB(input){
    const model = loadModel();
    const qT = tokenize(input||'');
    const vocabSize = Object.keys(model.vocab).length || 1;
    const results = [];
    for(const label in model.labels){
      const lbl = model.labels[label];
      // prior: P(label) ~ lbl.count / docCount
      const prior = (model.docCount>0) ? (lbl.count / model.docCount) : (1 / (Object.keys(model.labels).length || 1));
      // likelihood: product of (tokenCount + 1) / (totalTokensInLabel + vocabSize) -- use log to avoid underflow
      let totalTokensInLabel = 0;
      for(const t in lbl.tokenCounts) totalTokensInLabel += lbl.tokenCounts[t];
      if(totalTokensInLabel === 0) totalTokensInLabel = 0;
      let logProb = Math.log(prior + 1e-12);
      for(const t of qT){
        const tc = lbl.tokenCounts[t] || 0;
        logProb += Math.log((tc + 1) / (totalTokensInLabel + vocabSize) + 1e-12);
      }
      results.push({ label, score: logProb });
    }
    // sort by score desc
    results.sort((a,b) => b.score - a.score);
    return results; // array of {label, score}
  }

  // find best response using: exact memory -> NB predict -> token overlap memory -> fallback
  function findBest(input){
    const mem = loadMemory();
    const q = (input||'').trim();
    if(!q) return { response: DEFAULT_RESPONSES[1], source: 'empty' };

    // exact match
    for(const item of mem){
      if(item.input && item.input.toLowerCase() === q.toLowerCase()){
        return { response: item.response, source: 'exact', item };
      }
    }
    // NB predict
    const nb = predictNB(q);
    if(nb && nb.length>0){
      const top = nb[0];
      // only trust model if reasonably higher than fallback; we use score diff heuristic
      if(nb.length===1 || (top.score - nb[1].score) > 1.0){
        return { response: top.label, source: 'naive-bayes', probs: nb };
      }
    }
    // token overlap fallback (most common overlapping response)
    const qT = tokenize(q);
    let best = null; let bestScore = 0;
    for(const item of mem){
      const toks = tokenize(item.input||'');
      const common = qT.filter(t => toks.includes(t)).length;
      const score = common * Math.log(1 + (item.count||1));
      if(score > bestScore){ bestScore = score; best = item; }
    }
    if(best && bestScore>0){
      return { response: best.response, source: 'token-overlap', item: best, score: bestScore };
    }
    // fallback default
    return { response: DEFAULT_RESPONSES[Math.floor(Math.random()*DEFAULT_RESPONSES.length)], source: 'fallback' };
  }

  function recordInteraction(input, response, reinforce){
    const mem = loadMemory();
    const lower = (input||'').trim();
    for(const item of mem){
      if(item.input && item.input.trim() === lower && item.response === response){
        item.count = (item.count||0) + (reinforce?1:1); // weak learning by default
        saveMemory(mem); trainFromMemory();
        return;
      }
    }
    mem.push({ input: (input||'').trim(), response: response, count: 1 });
    saveMemory(mem); trainFromMemory();
  }

  // Public API
  function send(input){
    const res = findBest(input);
    // record weakly by default so engine adapts
    try { recordInteraction(input, res.response, false); } catch(e){ console.warn('ai recordInteraction failed', e); }
    return res;
  }

  function reinforce(input, response){
    // reinforce increases count and retrains
    const mem = loadMemory();
    const lower = (input||'').trim();
    for(const item of mem){
      if(item.input && item.input.trim() === lower && item.response === response){
        item.count = (item.count||0) + 5; // stronger reinforcement
        saveMemory(mem); trainFromMemory();
        return true;
      }
    }
    // if not found, add and reinforce
    mem.push({ input: lower, response: response, count: 5 });
    saveMemory(mem); trainFromMemory();
    return true;
  }

  function exportMemory(){ return JSON.stringify(loadMemory(), null, 2); }
  function importMemory(jsonText, merge=true){
    try{
      const parsed = JSON.parse(jsonText);
      if(!Array.isArray(parsed)) return false;
      if(!merge){ saveMemory(parsed); trainFromMemory(); return true; }
      const mem = loadMemory();
      for(const e of parsed){
        if(!mem.find(m => m.input === e.input && m.response === e.response)){
          mem.push(e);
        }
      }
      saveMemory(mem); trainFromMemory(); return true;
    }catch(e){ console.warn('ai importMemory', e); return false; }
  }

  function exportModel(){ return JSON.stringify(loadModel(), null, 2); }
  function importModel(jsonText, merge=true){
    try{
      const parsed = JSON.parse(jsonText);
      if(typeof parsed !== 'object') return false;
      if(!merge){ saveModel(parsed); return true; }
      const model = loadModel();
      // simple merge: merge label counts and token counts
      for(const label in parsed.labels || {}){
        if(!model.labels[label]) model.labels[label] = { count: 0, tokenCounts: {} };
        model.labels[label].count = (model.labels[label].count || 0) + (parsed.labels[label].count || 0);
        for(const t in parsed.labels[label].tokenCounts || {}){
          model.labels[label].tokenCounts[t] = (model.labels[label].tokenCounts[t]||0) + (parsed.labels[label].tokenCounts[t]||0);
        }
      }
      model.docCount = (model.docCount || 0) + (parsed.docCount || 0);
      for(const t in parsed.vocab || {}) model.vocab[t] = (model.vocab[t]||0) + parsed.vocab[t];
      saveModel(model); return true;
    }catch(e){ console.warn('ai importModel', e); return false; }
  }

  function clearMemory(){ localStorage.removeItem(MEM_KEY); trainFromMemory(); }
  function clearModel(){ localStorage.removeItem(MODEL_KEY); }

  // Expose
  window.aiEngine = {
    send,
    train,
    reinforce,
    exportMemory,
    importMemory,
    exportModel,
    importModel,
    clearMemory,
    clearModel,
    _keys: { MEM_KEY, MODEL_KEY }
  };

  console.info('aiEngine hybrid learner loaded. Keys:', MEM_KEY, MODEL_KEY);

  // auto-train on load if memory exists but model empty
  (function autoTrainCheck(){
    try{
      const mem = loadMemory();
      const model = loadModel();
      if(mem.length>0 && (!model || Object.keys(model.labels||{}).length===0)){
        trainFromMemory();
      }
    }catch(e){}
  })();

})(window);
