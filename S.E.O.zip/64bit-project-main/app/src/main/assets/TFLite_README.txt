README - TFLite Integration Added

This project has been updated to include example native integration with TensorFlow Lite.

What's included:
- app/build.gradle: dependency 'org.tensorflow:tensorflow-lite:2.17.0' added.
- app/src/main/java/com/example/aiassistant/AiNativeEngine.java: example Java wrapper that loads a .tflite model from assets and runs inference with optional NNAPI delegate.
- AndroidManifest.xml: RECORD_AUDIO permission added (for real-time audio capture examples).

How to use:
1. Put your TensorFlow Lite model file (e.g. model.tflite) into app/src/main/assets/models/
2. From Java, create AiNativeEngine with:
   AiNativeEngine engine = new AiNativeEngine(context, "models/model.tflite", true); // true to attempt NNAPI
3. Prepare input float[] with the expected shape and call runInference(input, outputSize)
4. Close when done: engine.close()

Notes:
- This example assumes you will handle model pre-processing (resizing, normalization) in Java/Kotlin.
- To leverage vendor-specific delegates (Qualcomm Hexagon, MediaTek NeuroPilot/LiteRT) you may need additional SDKs and model compilation steps; see README_VENDOR.md for links.
- The app's WebView-based UI can communicate with native code via Android's JavaScriptInterface (not included here). You can expose aiEngine endpoints to JS if desired.

References & docs:
- TensorFlow Lite Android: https://www.tensorflow.org/lite
- NNAPI delegate: https://www.tensorflow.org/lite/performance/nnapi
- Qualcomm Hexagon delegate: check Qualcomm docs
- MediaTek LiteRT / NeuroPilot: check MediaTek docs


---
# 3D Viewer (WebGL) added
A simple WebGL-based 3D viewer (rotating cube placeholder) has been added to the assets:
- File: app/src/main/assets/js/three_viewer.js
- The viewer is embedded in index.html under "3D Viewer (WebGL)".

## How to replace placeholder with a real glTF model
The simple viewer is dependency-free and demonstrates a 3D canvas. To load glTF models, recommended approaches:
- Use Three.js + GLTFLoader (recommended for complex scenes). For offline use, add `three.min.js` and `GLTFLoader.js` into `app/src/main/assets/js/` and update `index.html` to load them before your loader script.
- Alternatively use native Android rendering (Filament) for high-performance 3D: see "Vendor/native 3D" below.

## Native 3D (Filament) option
If you need high-performance native 3D (better textures, PBR, glTF support), consider Filament:
- Filament: https://github.com/google/filament
- Add Filament AARs and JNI glue; requires more native setup but gives best mobile performance.
- For Sceneform-like experience, consider using Filament + Android SDK.

