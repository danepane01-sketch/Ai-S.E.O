const fs = require("fs");
const path = require("path");

function log(msg) {
    const t = new Date().toISOString();
    console.log(`[AI-BOT] ${t} — ${msg}`);
}

function updateData() {
    const dataPath = path.join(__dirname, "data.json");

    let data = {};
    if (fs.existsSync(dataPath)) {
        data = JSON.parse(fs.readFileSync(dataPath));
    }

    data.last_update = new Date().toISOString();
    data.ai_status = "running";
    data.version = (data.version || 0) + 1;

    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2));
    log("Data updated successfully");
}

updateData();